<template>
  <div>
    <TopNavTwo />
    <Metrics />
  </div>
</template>

<script>
  import Metrics from '../components/Metrics'
  import TopNavTwo from '../components/TopNavTwo'

  export default {
    components: {
      Metrics,
      TopNavTwo
    }
  }
</script>