<template>
    <AddJob />
</template>

<script>
import AddJob from '../components/AddJob.vue'
export default {
    components: {
        AddJob
    },
    data () {
        return {

        }
    }
}
</script>